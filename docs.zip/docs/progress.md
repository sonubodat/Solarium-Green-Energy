# Development Progress

## Current status

- Foundation implementation is in progress.
- Frontend/backend connection and the initial backend structure are implemented.
- Core role separation is defined as ADMIN, SALES, and VENDOR.
- Supabase is documented as the PostgreSQL provider.
- Vendor login is defined as username or mobile number plus password.
- Admin forgot-password or change-password access is now part of the plan.
- Vendor password reset from the dashboard is now part of the plan.
- `frontend/` and `backend/` application boundaries have been scaffolded.
- Prisma schema, seed entry point, API route boundaries, middleware, and shared frontend API client have been scaffolded.
- Server-side session lookup and reusable Admin, Sales, Vendor, and Admin-or-Sales authorization guards are implemented.
- Staff and Vendor login, logout, and password-change endpoints are implemented with hashed passwords and server-managed sessions.
- Frontend and backend `.env.example` and `.gitignore` boundaries are configured; secrets and generated artifacts are excluded from commits.
- Password reset issuance and completion are implemented with hashed, expiring, single-use reset tokens; reset tokens are never returned in production responses.
- A visible frontend portal preview is implemented with Public, Vendor, Sales, and Admin views using text-only status presentation.
- Prisma client generation is automatic after backend installation and before startup for local and Render environments.
- Prisma is now consistently configured for Prisma 7 with `prisma.config.ts`, the PostgreSQL adapter, and matching pinned package versions.
- Prisma version consistency was restored after an unsafe `npm audit fix --force` downgrade; Prisma packages must remain pinned together.
- Public vendor registration and authenticated Vendor profile retrieval are implemented against the Prisma data model with input validation and normalized mobile/login identifiers.
- Schema integrity hardening is prepared: VendorRegistration status is typed, and the database migration enforces one active QR assignment per QR.
- Sales registration visibility and transactional Vendor onboarding are implemented with Sales ownership checks and hashed initial credentials.
- The applied baseline migration was restored unchanged after Prisma detected migration drift; follow-up migrations contain the schema hardening changes.
- Local Prisma Client generation and API startup succeed on port `4000`.
- Supabase connectivity is now working; migration status reached the database and reported the two pending follow-up migrations.
- Supabase migrations are now fully applied; Prisma reports the database schema is up to date.
- Prisma migration configuration now prefers `DIRECT_URL`, allowing the runtime pooler URL and migration connection URL to be configured separately.
- QR inventory listing and generation, Sales unassigned-QR assignment, and Admin transactional QR reassignment are implemented with audit logging.
- Public QR resolution now validates the current assignment, records immutable scan attribution, returns safe referral context, and applies single-instance rate limiting.
- Public lead capture now validates the scan, normalizes Indian mobile numbers, creates HMAC customer identities, preserves attribution, and records duplicate leads as `DUPLICATE`.
- Vendor lead and manual payout views are implemented with authenticated Vendor scoping, bounded pagination, protected customer fields, and text-only payout statuses.
- Admin operational list views for vendors, leads, scans, payouts, and audit logs are implemented with Admin authorization and bounded pagination.
- Admin Vendor create/update/deactivate, lead status changes, and manual payout marking are implemented with validation, transactions, and audit logging.
- Admin staff-user listing, creation, update, and deactivation are implemented with hashed passwords, audit logging, and last-Admin protection.
- The applied baseline migration remains unchanged; `RESTRICT` is valid PostgreSQL syntax and its editor underline is a dialect warning, not a runtime issue.
- Development seed data now provides repeatable Admin, Sales, Vendor, and QR records for Postman/API verification.
- CORS now supports a comma-separated browser-origin allowlist for local, Render, Vercel, and temporary ngrok testing; expected `401/403` responses are no longer logged as server errors.
- Production session cookies use configurable `SameSite=None; Secure` behavior for the separate Vercel frontend and Render backend.
- A client-facing RFI has been prepared covering the product scope, technical approach, security model, current progress, exclusions, acceptance scenarios, and information required from Solarium Energy.
- Security hardening now rate-limits staff and Vendor login attempts and password-reset requests per client IP, while preserving generic authentication and reset responses.
- The frontend now connects the Public QR/lead workflow and authenticated Vendor, Sales, and Admin entry workflows to the live API with loading, success, and error states.
- The Sales frontend now supports pending-registration selection, temporary-password onboarding, QR status lookup, and assignment of an unassigned QR using the returned Vendor identifier.
- The Admin frontend now loads bounded operational views for vendors, QR inventory, leads, scans, payouts, staff users, and audit logs through a resource selector.
- The Vendor frontend now renders the authenticated Vendor workspace with profile, referral, payout-status, empty, and first-login password-change states without exposing customer phone numbers.
- The Admin Vendor resource view now supports the first mutation slice: create Vendor, issue a temporary-password reset, and deactivate a Vendor, each with a confirmation prompt and an automatic list refresh. Other Admin resources remain read-only for now.
- The Admin QR resource view now supports the second mutation slice: generate a QR batch by quantity, and reassign an `ACTIVE` QR to a target Vendor ID, each with a confirmation prompt and an automatic list refresh. Reassignment is only offered in the UI for `ACTIVE` QR codes, matching the backend's `QR_NOT_ACTIVE` rule.
- The Admin Leads resource view now supports the third mutation slice: change a lead's status via a per-row selector confirmed before submission, with an automatic list refresh. Vendor/QR/scan attribution fields are not editable from this view.
- The Admin Payouts resource view now supports the fourth mutation slice: mark an `UNPAID` payout as `PAID` with a required manual payment reference, confirmed before submission and followed by an automatic list refresh. The action is only offered in the UI for `UNPAID` records; `paid_at` and `paid_by` are set server-side.
- The Admin Staff users resource view now supports the fifth mutation slice: create a staff user (`ADMIN`/`SALES`), update a staff user's role, and deactivate a staff user, each confirmed before submission and followed by an automatic list refresh.
- The Admin Vendor mutation slice gained the general "edit vendor" action alongside create/reset-password/deactivate: an inline form updates business name, owner name, login identifier, and mobile number via `PATCH /api/admin/vendors/:vendorId`, confirmed before saving.
- Admin mutation controls are now implemented for every resource that has a documented mutation action (vendors, QR, leads, payouts, staff users). Scans and audit logs remain read-only by design; no mutation action is defined for them.

- Phase 17 production-readiness spot checks completed locally: `frontend` production build compiles cleanly (`npm run build`, 65 kB gzip main bundle); no `.env` files are tracked in git and `.gitignore` correctly excludes them in the root, `backend`, and `frontend`; no hardcoded secrets found in `backend/src`; `npx prisma generate` succeeds from the committed schema; `npx prisma migrate status` against the configured Supabase database reports the schema is up to date (3 migrations applied, none pending). CORS and session-cookie code (`backend/src/app.js`, `backend/src/config/env.js`, `backend/src/services/auth.js`) were re-read against `plan.md`'s security requirements and match: origin allowlist from `CORS_ORIGINS`, credentials + `Vary: Origin`, `HttpOnly`/configurable `SameSite`/`Secure`-in-production cookies, session tokens stored only as hashes.

- A full manual/curl/Postman/Supabase testing guide is now available at `docs/testing.md`, covering every implemented endpoint's exact request body and expected response, end-to-end acceptance scenarios, Supabase SQL checks, and a frontend walkthrough. Use it for the verification pass referenced below instead of re-deriving request shapes from `api.md`.

- Backend hardening pass: `POST /api/admin/vendors/:vendorId/reset-password` now writes a `VENDOR_PASSWORD_RESET` audit row (previously missing, flagged by `docs/testing.md`); the in-memory rate-limit cache now evicts expired window entries on a 5-minute sweep instead of growing unbounded for the life of the process; the password-reset token TTL is now configurable via `PASSWORD_RESET_TTL_MINUTES` (default 15 minutes, unchanged behavior); Admin users can no longer deactivate or demote their own account (`CANNOT_MODIFY_OWN_ACCOUNT`, `409`) via either `POST /api/admin/users/:userId/deactivate` or `PATCH /api/admin/users/:userId`, independent of and checked before the existing last-active-Admin protection.

- QR printing/export step 1 of 5 complete: `qrcode` dependency added and `backend/src/services/qr-image.js` generates SVG/PNG QR images encoding only the public referral URL, verified functionally.
- QR printing/export step 2 of 5 complete: `GET /api/admin/qr/:qrId/image?format=svg|png` added, verified live against the dev Supabase database (correct content-types, real PNG confirmed, 404/401/403 all correct).
- QR printing/export step 3 of 5 complete: `GET /api/admin/qr/print?status=&vendor_id=&page=&limit=` added — a self-contained, print-friendly HTML export (inline SVGs, no server-side PDF dependency), bounded by the same `pagination()` convention used everywhere else in the Admin API (capped at 100, not the earlier "200" placeholder). Verified live for every filter combination, the pagination clamp, and the auth/role boundary.
- App-wide correctness fix, found while verifying step 3: `backend/src/middleware/errors.js` did not special-case Zod validation errors, so every Zod-validated route in the backend returned `500` instead of the documented `400` on invalid input. Fixed centrally — `ZodError` now maps to `400 VALIDATION_ERROR` with a `{path, message}` details array. Verified live on two independent routes (`POST /admin/vendors`, `GET /admin/qr/print`). This was a real, previously-undetected gap between `api.md`'s documented contract and the actual implementation across the whole API, not specific to QR printing.
- QR printing/export step 4 of 5 complete: Admin QR resource view now has a Print/export panel (status filter, optional Vendor ID filter, "Open printable sheet") and per-row SVG/PNG download links. Verified live in a real browser end-to-end (login, filter, open sheet, download image) against the already-running frontend dev server and a temporary backend instance, not just linted. Fixed a real cosmetic bug found during that check: the print sheet had no explicit background color and rendered black in a dark-mode browser.
- QR printing/export step 5 of 5 complete: `docs/testing.md` fully covers the QR image/print endpoints (curl commands, frontend walkthrough step, checklist line). The QR printing/export slice from `RFI.md`'s previously-open question is now fully implemented, documented, and verified end to end.
- **Full `docs/testing.md` verification pass completed** (§§3–11: Public, Auth, Vendor, Sales, Admin, pagination, Supabase-equivalent integrity checks via Prisma, end-to-end acceptance scenarios, and a real-browser frontend walkthrough of all four portals). Six real defects were found and fixed, each reproduced live before and after the fix, not assumed:
  1. **`VendorRegistration` had no unique constraint** on `login_identifier` — duplicate pending registrations could be created silently (the route's own `P2002` handling was dead code). Fixed with migration `20260825093500_vendor_registration_login_identifier_unique`; verified duplicate registration now returns `409`.
  2. **`Retry-After` header always said `60`**, even on the 15-minute auth/password-reset limiters, because a generic response helper overwrote the correctly-computed value. Fixed in `rate-limit.js`; verified the header now reports the real remaining window (~897s on a fresh trip).
  3. **`POST /admin/qr/:qrId/reassign` leaked the vendor's `passwordHash`** in the JSON response — every other vendor-returning endpoint wrapped with `publicVendor()`, this one didn't. Fixed; verified the field is gone from the response.
  4. **Deactivating a Vendor or staff user did not revoke their existing session** — a deactivated account kept full API access on its pre-existing session cookie (fresh logins correctly failed, but `requireAuth` never re-checked account status on existing sessions). This defeated the actual purpose of deactivation as an access-revocation control. Fixed in `middleware/auth.js`: `requireAuth` now rejects with `401` if the session's account is not `ACTIVE`. Verified live: a deactivated Vendor's existing session immediately returns `401`.
  5. **The public enquiry form broke whenever the optional Email field was left blank** — the frontend sent `email: ""` rather than omitting the key, and the backend's `.email().optional()` validator rejects an empty string. This broke the primary customer-facing conversion flow for the common case of a customer skipping an optional field. Fixed in `App.js`'s `submitLead` (strips empty `email`/`location` before sending, matching the existing pattern used for optional fields elsewhere); verified live in the browser.
  6. **The app's runtime connected via Supabase's transaction-mode pooler (port 6543)**, which is a documented Prisma incompatibility for interactive `$transaction()` under concurrent load — affecting every mutation in the app (not just leads). Reproduced live (intermittent `P2028` failures under load), root-caused with isolated port-comparison tests, and fixed by routing the runtime connection through `DIRECT_URL` (session-mode, port 5432) instead, matching what `prisma.config.ts` already used for the CLI. Verified with a 20-concurrent-transaction stress test (20/20 succeeded post-fix) and a clean browser walkthrough. See `architecture.md` for the scaling note this leaves for later.
  - Full findings detail, evidence, and reproduction steps are preserved in this session's scratch findings log for reference; the summary above is the durable record.
  - Everything else in `docs/testing.md` — the entire Public/Auth/Vendor/Sales/Admin/QR-printing endpoint surface, pagination bounds, historical-attribution-after-reassignment (the system's most business-critical guarantee), duplicate-customer detection, and the last-Admin/self-lockout staff protections — passed with no defects found.

## Next step

- The QR printing/export slice, the backend hardening pass, and the full `docs/testing.md` verification pass (with 6 fixed defects, detailed above) are all complete. The application has been exercised end-to-end against the live dev Supabase database and in a real browser, not just linted. Remaining Phase 17 items that need the client's production values (not verifiable locally): final `CORS_ORIGINS`/`FRONTEND_ORIGIN` for the deployed frontend, and a cross-browser check of `SameSite=None; Secure` cookies once both apps are actually deployed. You (the developer) should still run your own independent Postman pass per `docs/testing.md` as originally planned — an automated pass reduces risk but doesn't replace manual review, especially for anything touching money (payouts) or access control.

## Notes

- This file is for development tracking only.
- Keep implementation work module-by-module.
- Scaffold files are not feature-complete implementations; update this file as each route and workflow becomes functional.